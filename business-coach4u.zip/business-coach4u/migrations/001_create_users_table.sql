-- 001_create_users_table.sql
-- Business Coach4U — initial schema for membership gating
-- Run this in the Supabase SQL editor after creating the project.

create table public.users (
  id                uuid primary key references auth.users(id) on delete cascade,
  email             text not null,
  full_name         text,
  membership_status text not null default 'inactive',
  created_at        timestamptz default now()
);

alter table public.users enable row level security;

create policy "Users can read their own row"
  on public.users for select
  using (auth.uid() = id);

create policy "Users can update their own row"
  on public.users for update
  using (auth.uid() = id);

-- After a user signs up, activate their membership by running:
--
--   INSERT INTO users (id, email, membership_status)
--   SELECT id, email, 'active'
--   FROM auth.users
--   WHERE LOWER(email) = LOWER('email@here.com');
--
-- Replace 'email@here.com' with the member's actual email address.
