// js/app.js — Business Coach4U panel logic
// This file is a placeholder. All panel logic (VTO save/load, accountability chart,
// goals CRUD, scorecard, meetings, issues, team alignment, business switcher)
// will be built here in the next phase.
//
// Once authentication is confirmed working, hand the empty app over to Claude Code
// with a clear scope per panel and build them one at a time.

(function() {
  'use strict';

  // Hide vision banner gracefully until VTO data exists
  // Wire up any global UI toggles that should work before app data loads

  // Sign-out is already wired via window.signOut in the auth gate at the top of index.html

  // Toast helper available to the rest of app.js when it lands
  window.toast = (message, type = 'success') => {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = message;
    el.className = 'toast ' + (type === 'error' ? 'toast-error' : 'toast-success');
    el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), 2400);
  };

  console.log('Business Coach4U — auth confirmed, ready to load panel logic.');
})();
